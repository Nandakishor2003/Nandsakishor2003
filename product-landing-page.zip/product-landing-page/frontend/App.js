// src/App.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProductForm from './components/ProductForm';
import ProductList from './components/ProductList';
import './styles.css';

const App = () => {
  const [products, setProducts] = useState([]);

  const fetchProducts = async () => {
    const response = await axios.get('http://localhost:5000/api/products');
    setProducts(response.data);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="container">
      <h1>Product Dashboard</h1>
      <ProductForm fetchProducts={fetchProducts} />
      <ProductList products={products} fetchProducts={fetchProducts} />
    </div>
  );
};

export default App;
