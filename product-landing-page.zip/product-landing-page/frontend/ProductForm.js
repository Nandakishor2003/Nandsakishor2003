// src/components/ProductForm.js
import React, { useState } from 'react';
import axios from 'axios';

const ProductForm = ({ fetchProducts }) => {
  const [product, setProduct] = useState({ name: '', description: '', price: '' });

  const handleChange = e => {
    const { name, value } = e.target;
    setProduct({ ...product, [name]: value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/products', product);
    setProduct({ name: '', description: '', price: '' });
    fetchProducts();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" value={product.name} onChange={handleChange} placeholder="Name" />
      <input name="description" value={product.description} onChange={handleChange} placeholder="Description" />
      <input name="price" value={product.price} onChange={handleChange} placeholder="Price" />
      <button type="submit">Add Product</button>
    </form>
  );
};

export default ProductForm;
