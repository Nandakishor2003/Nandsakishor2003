// src/components/ProductList.js
import React from 'react';
import axios from 'axios';

const ProductList = ({ products, fetchProducts }) => {
  const handleDelete = async id => {
    await axios.delete(`http://localhost:5000/api/products/${id}`);
    fetchProducts();
  };

  return (
    <ul>
      {products.map(product => (
        <li key={product.id}>
          {product.name} - {product.description} - {product.price}
          <button onClick={() => handleDelete(product.id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
};

export default ProductList;
